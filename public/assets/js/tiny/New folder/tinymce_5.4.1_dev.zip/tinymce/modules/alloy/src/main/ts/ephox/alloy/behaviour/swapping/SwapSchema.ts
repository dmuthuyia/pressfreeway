import { FieldSchema } from '@ephox/boulder';

export default [
  FieldSchema.strict('alpha'),
  FieldSchema.strict('omega')
];
