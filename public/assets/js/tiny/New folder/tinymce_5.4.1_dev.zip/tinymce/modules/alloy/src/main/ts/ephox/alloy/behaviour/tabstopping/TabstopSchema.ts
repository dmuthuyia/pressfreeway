import { FieldSchema } from '@ephox/boulder';

export default [
  FieldSchema.defaulted('tabAttr', 'data-alloy-tabstop')
];
